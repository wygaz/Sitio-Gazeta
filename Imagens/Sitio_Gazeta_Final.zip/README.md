# Sítio Gazeta - Mapa com Legenda

Este projeto contém uma versão estática da visualização do mapa do Sítio Gazeta com uma legenda explicativa. Os pontos numerados no mapa são descritos em duas colunas abaixo da imagem.

## Como usar

1. Extraia o conteúdo do ZIP.
2. Certifique-se de que o arquivo `mapa.png` esteja na mesma pasta do `index.html`.
3. Abra o arquivo `index.html` no seu navegador.
