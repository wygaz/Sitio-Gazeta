# Sítio Gazeta - Mapa de Localização

Este projeto apresenta um **mapa estático** com a visualização dos principais pontos de interesse ao redor do Sítio Gazeta, localizado próximo ao UNASP-EC (Engenheiro Coelho).

## Conteúdo

- `index.html`: página principal com o mapa e a legenda explicativa.
- `mapa.png`: imagem estática do mapa com os pontos numerados.
